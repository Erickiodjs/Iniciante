
 var min = 00;
 var sec =0;
 var temp;

function iniciar(){
    
    temp=setInterval(resultado,1000)
}
function Recomeçar(){
   
  sec=00
  min=00
}

function resultado() {
    sec++
     document.getElementById("valor").innerHTML=min+":"+sec
     if(sec==60){
        min++
        sec=0
     }
   
}
function parar(){
    clearInterval(temp)
   
}